import React, { useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';

export default function App() {
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');

  const handleInput = (val) => {
    setInput(input + val);
  };

  const calculateResult = () => {
    try {
      setResult(eval(input).toString());
    } catch (e) {
      setResult('Error');
    }
  };

  const handleClear = () => {
    setInput('');
    setResult('');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.input}>{input}</Text>
      <Text style={styles.result}>{result}</Text>
      <View style={styles.buttons}>
        <View style={styles.row}>
          <TouchableOpacity onPress={() => handleInput('1')} style={styles.button}><Text>1</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => handleInput('2')} style={styles.button}><Text>2</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => handleInput('3')} style={styles.button}><Text>3</Text></TouchableOpacity>
        </View>
        <View style={styles.row}>
          <TouchableOpacity onPress={() => handleInput('4')} style={styles.button}><Text>4</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => handleInput('5')} style={styles.button}><Text>5</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => handleInput('6')} style={styles.button}><Text>6</Text></TouchableOpacity>
        </View>
        <View style={styles.row}>
          <TouchableOpacity onPress={() => handleInput('7')} style={styles.button}><Text>7</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => handleInput('8')} style={styles.button}><Text>8</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => handleInput('9')} style={styles.button}><Text>9</Text></TouchableOpacity>
        </View>
        <View style={styles.row}>
          <TouchableOpacity onPress={() => handleInput('0')} style={styles.button}><Text>0</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => handleInput('+')} style={styles.button}><Text>+</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => handleInput('-')} style={styles.button}><Text>-</Text></TouchableOpacity>
          <TouchableOpacity onPress={calculateResult} style={styles.button}><Text>=</Text></TouchableOpacity>
        </View>
        <TouchableOpacity onPress={handleClear} style={styles.clearButton}><Text>Clear</Text></TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    fontSize: 32,
    marginBottom: 20,
  },
  result: {
    fontSize: 48,
    marginBottom: 20,
  },
  buttons: {
    width: '80%',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#ddd',
    padding: 20,
    width: '22%',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
  },
  clearButton: {
    backgroundColor: '#f00',
    padding: 20,
    marginTop: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
  },
});
